package jdbcOperation;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import DAO.UserDao;

public class record {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		
		 ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		 //UserDao ud = context.getBean("UserDAO",UserDao.class); 
		 UserDao ud= context.getBean("userDao", UserDao.class);
		 ud.selectAllRows();
	}

}
