package DAO;

import java.sql.*;
public class UserDao {
	private String driver;
    private String url;
    private String userName;
    private String password;
  
  
    public void setDriver(String driver)
    {
        this.driver = driver;
    }
  
    
    public void setUrl(String url) { this.url = url; }
  
 
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
  
   
    public void setPassword(String password)
    {
        this.password = password;
    }
  
    
    public void selectAllRows() throws ClassNotFoundException, SQLException
    {
        System.out.println("Retrieving all student data..");
  
        
        Class.forName(driver);
  
       
        Connection con = DriverManager.getConnection(url, userName, password);
  
       
        Statement stmt = con.createStatement();
  
        ResultSet rs = stmt.executeQuery("SELECT * FROM springjdbc.login");
  
        while (rs.next()) {
            int studentId = rs.getInt(1);
            String studentName = rs.getString(2);
            double hostelFees = rs.getDouble(3);
            String wing = rs.getString(4);
  
            System.out.println(studentId + " " + studentName
                               + " " + hostelFees + " "
                               + wing);
        }
  
        
        con.close();
    }
}
